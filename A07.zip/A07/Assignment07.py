# ------------------------------------------------- #
# Title: Assignment07
# Desc: This assignment demonstrates using dictionaries, files, and exception handling
# Change Log: (Who, When, What)
# RRoot,1/1/2030,Created Script
# Ace Bailey, 8/13/2024, Created Script
# ------------------------------------------------- #
import json

# Constants -------------------------------------------- #
FILE_NAME: str = "Enrollments.json"
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course
    2. Show current data  
    3. Save data to a file
    4. Exit the program
-----------------------------------------
'''

# Variables -------------------------------------------- #
students: list = []  # a table of student data
menu_choice = ''

# Classes -------------------------------------------- #

class Person:
    def __init__(self, student_first_name: str = '', student_last_name: str = ''):
        self.student_first_name = student_first_name
        self.student_last_name = student_last_name

class Student(Person):
    def __init__(self, student_first_name: str = '', student_last_name: str = '', course_name: str = ''):
        super().__init__(student_first_name=student_first_name, student_last_name=student_last_name)
        self.course_name = course_name

class FileProcessor:
    @staticmethod
    def read_data_from_file(file_name: str, student_data: list):
        try:
            with open(file_name, "r") as file:
                list_of_dictionary_data = json.load(file)
                for student in list_of_dictionary_data:
                    student_object = Student(student_first_name=student["FirstName"],
                                             student_last_name=student["LastName"],
                                             course_name=student["CourseName"])
                    student_data.append(student_object)
            print("DEBUG: Data successfully read from file.")
        except FileNotFoundError as e:
            IO.output_error_messages("Text file must exist before running this script!", e)
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)
        return student_data

    @staticmethod
    def write_data_to_file(file_name: str, student_data: list):
        try:
            list_of_dictionary_data = []
            for student in student_data:
                student_json = {"FirstName": student.student_first_name,
                                "LastName": student.student_last_name,
                                "CourseName": student.course_name}
                list_of_dictionary_data.append(student_json)

            with open(file_name, "w") as file:
                json.dump(list_of_dictionary_data, file)
            print("DEBUG: Data successfully written to file.")
        except TypeError as e:
            IO.output_error_messages("Please check that the data is a valid JSON format", e)
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)

class IO:
    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        if error:
            print(f"ERROR: {message} \n{error}")
        else:
            print(f"ERROR: {message}")

    @staticmethod
    def output_menu(menu: str):
        print(menu)

    @staticmethod
    def input_menu_choice():
        """ This function gets a menu choice from the user

        ChangeLog: (Who, When, What)
        YourName,Today's Date,Created function

        :return: string with the user's choice
        """
        choice = "0"  # Default choice if an error occurs
        try:
            # Get input from the user and remove any leading/trailing whitespace
            choice = input("Enter your menu choice number: ").strip()

            # Check if the choice is valid
            if choice not in ("1", "2", "3", "4"):  # These are the valid menu options
                raise Exception("Invalid choice! Please choose only 1, 2, 3, or 4.")

        except Exception as e:
            # Output the error message to the user
            IO.output_error_messages(e.__str__())  # Avoiding the technical error details

        return choice

    @staticmethod
    def output_student_courses(student_data: list):
        print()
        print("-" * 50)
        for student in student_data:
            print(f'{student.student_first_name} {student.student_last_name} registered for {student.course_name}')
        print("-" * 50)
        print()

    @staticmethod
    def input_student_data(student_data: list):
        try:
            student = Student()
            student.student_first_name = input("What is the student's first name? ")
            student.student_last_name = input("What is the student's last name? ")
            student.course_name = input("What is the course name? ")
            student_data.append(student)
        except ValueError as e:
            IO.output_error_messages("That value is not the correct type of data!", e)
        except Exception as e:
            IO.output_error_messages("There was a non-specific error!", e)
        return student_data

# Main Body of Script --------------------------------------- #
students = FileProcessor.read_data_from_file(file_name=FILE_NAME, student_data=students)

while True:
    IO.output_menu(menu=MENU)

    menu_choice = IO.input_menu_choice()

    if menu_choice == "1":  # Register a student for a course
        students = IO.input_student_data(student_data=students)
        continue

    elif menu_choice == "2":  # Show current data
        IO.output_student_courses(student_data=students)
        continue

    elif menu_choice == "3":  # Save data to a file
        FileProcessor.write_data_to_file(file_name=FILE_NAME, student_data=students)
        continue

    elif menu_choice == "4":  # Exit the program
        break  # Exit the loop
